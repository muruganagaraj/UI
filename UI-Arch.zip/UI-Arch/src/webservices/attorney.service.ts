// /* tslint:disable */
// import { NgModule, Injectable } from '@angular/core';
// import { HttpClientModule, HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs/Observable';
// import { ConfigurationModule } from '../configuration/configuration.module';
// import { Configuration } from '../configuration/configuration';

// @Injectable()
// export class AlertWebService {
//     constructor(private httpClient: HttpClient, private configuration: Configuration) {
//     }
//     public Alert_PostAsync(alertsRequest: any): Observable<attorney.model.ApiResultModelGetRequiredAlertsReponse> {
//         let resourceUrl: string = '/api/alerts/async';
//         let queryParams: any = {
//         };
//         return this.httpClient.post<attorney.model.ApiResultModelGetRequiredAlertsReponse>(buildServiceUrl(this.configuration.ApiServer, resourceUrl, queryParams), alertsRequest);
//     }
//     public Alert_PostDismissAsync(dismissAlertRequest: attorney.model.DismissAlertRequest): Observable<attorney.model.ApiResultModelDismissAlertResponse> {
//         let resourceUrl: string = '/api/alerts/dismiss/async';
//         let queryParams: any = {
//         };
//         return this.httpClient.post<attorney.model.ApiResultModelDismissAlertResponse>(buildServiceUrl(this.configuration.ApiServer, resourceUrl, queryParams), dismissAlertRequest);
//     }
// }

// function buildServiceUrl(baseUrl: string, resourceUrl: string, queryParams?: any): string {
//     let url: string = baseUrl;
//     let baseUrlSlash: boolean = url[url.length - 1] === '/';
//     let resourceUrlSlash: boolean = resourceUrl[0] === '/';
//     if (!baseUrlSlash && !resourceUrlSlash) {
//         url += '/';
//     }
//     else if (baseUrlSlash && resourceUrlSlash) {
//         url = url.substr(0, url.length - 1);
//     }
//     url += resourceUrl;

//     if (queryParams) {
//         let isFirst: boolean = true;
//         for (let p in queryParams) {
//             if (queryParams.hasOwnProperty(p) && queryParams[p]) {
//                 let separator: string = isFirst ? '?' : '&';
//                 url += `${separator}${p}=${encodeURI(queryParams[p])}`;
//                 isFirst = false;
//             }
//         }
//     }
//     return url;
// }

// export namespace attorney.model {
//     export interface DismissAlertRequest {
//         sessionID: string;
//         userName: string;
//         loanNumber: string;
//         alertID: string;
//         isSandBox: boolean;
//     }
//     export interface ApiResultModelDismissAlertResponse {
//         items: DismissAlertResponse;
//     }
//     export interface DismissAlertResponse {
//         status: boolean;
//     }

//     export interface ApiResultModelGetRequiredAlertsReponse {
//         items: GetRequiredAlertsReponse;
//     }
//     export interface GetRequiredAlertsReponse {
//         alertsResponse: AlertResponse[];
//     }
//     export interface AlertResponse {
//         appDate: string;
//         id: string;
//         loanNumber: string;
//         applicationDate: Date;
//         lastName: string;
//         message: string;
//     }
// }

// @NgModule( {
//     imports:[ HttpClientModule, ConfigurationModule ],
//     providers: [ AlertWebService
//     ]
// }
// )
// export class AttorneyApiModule {
// }