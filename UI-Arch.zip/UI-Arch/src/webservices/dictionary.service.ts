export interface DictionaryModel {
[key: string]: string;
};

export class Dictionary {
    dictionaryValues: DictionaryModel = {}

    constructor() { }

    public setDictionary(key: string, value: any) {
        this.dictionaryValues[key] = value;
    }
}
