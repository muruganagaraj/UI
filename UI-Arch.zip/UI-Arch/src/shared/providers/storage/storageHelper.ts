import { Injectable } from '@angular/core';
import { BaseState, StateType } from './base-state.provider';

@Injectable()
export class StorageHelper extends BaseState {
    constructor() {
        super([
            { type: StateType.session, name: 'name' },
            { type: StateType.persisted, name: 'name1' },
        ])
    }

    public set name(value: string) {
        this.setState('name', value);
    }
    public get name(): string {
        return this.getState<string>('name');
    }
     public set name1(value: string) {
        this.setState('name1', value);
    }
    public get name1(): string {
        return this.getState<string>('name1');
    }
}