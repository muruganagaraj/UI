export enum MasterType {
    sampleExample
}