// Routes
export class RouteConstants {
    // 1. Home
    public static homeRoute: string = 'home';
}