export class ApiConstant {
    public static getEmployerrList: string = '/api/employee';
}