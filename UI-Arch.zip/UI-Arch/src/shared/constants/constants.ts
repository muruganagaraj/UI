export class Constants {
    public static unknownError: string = 'The application has encountered an unknown error';
}