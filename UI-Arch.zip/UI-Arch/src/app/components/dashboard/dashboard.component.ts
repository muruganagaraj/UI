import { Component, OnInit } from '@angular/core';
import * as uikit from 'uikit';
import { ToastrService } from 'ngx-toastr';
import { MastersService } from '../../../shared/services/master.service';
import { StorageHelper } from '../../../shared/providers/storage/storageHelper';
import { Configuration } from '../../../configuration/configuration';
import { AttorneyService } from '../../../webservices/attorney.services';
import { ApiConstant } from '../../../shared/constants/apiConstants';
import { Dictionary } from '../../../webservices/dictionary.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit {
  sampleDropdown: TextPair[] = [];
  phone: string = '1234567890';
  constructor(private toastr: ToastrService,
    private mastersService: MastersService,
    private storageHelper: StorageHelper,
    private config: Configuration,
    private attorneyService: AttorneyService) { }

  ngOnInit() {
    this.toastr.success('success');
    this.toastr.warning('warning');
    this.toastr.error('error');
    this.toastr.info('info');
    this.sampleDropdown = this.mastersService.sampleExample();

    this.storageHelper.name = 'Atterney first';
    this.storageHelper.name1 = 'Atterney first';
    console.log(this.storageHelper.name);
    console.log(this.config.externalUrls.facebook);
  }


  showAlert(): void {
    uikit.modal.alert('UIkit alert!');
  }

  showConfirm(): void {
    uikit.modal.confirm('UIkit confirm!').then(() => {
      let dictionaryObject: Dictionary = new Dictionary();
      dictionaryObject.setDictionary('loanNumber', 12123);
      dictionaryObject.setDictionary('loanID', 'sadad');
      console.log(dictionaryObject.dictionaryValues);
      this.attorneyService.Get(dictionaryObject.dictionaryValues, ApiConstant.getEmployerrList).subscribe((response: any) => {
        alert('success');
      });
      // const dismissAlertRequest: attorney.model.DismissAlertRequest = {
      //   sessionID: undefined,
      //   userName: undefined,
      //   loanNumber: undefined,
      //   alertID: undefined,
      //   isSandBox: undefined
      // };
      // this.alertWebService.Alert_PostDismissAsync(dismissAlertRequest).subscribe((response: any) => {
      //   alert('success');
      // });
    }, () => {
      alert('Cancel click');
    });
  }

  onChange(item: string): void {
    alert(item);
  }
}
