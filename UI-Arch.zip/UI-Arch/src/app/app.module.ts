import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HeaderComponent } from './masterComponents/header/header.component';
import { FooterComponent } from './masterComponents/footer/footer.component';
import { LoginComponent } from './components/authentication/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { PageNotFoundComponent } from './components/pageNotFound/pageNotFound.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { MastersService } from '../shared/services/master.service';
import { StorageHelper } from '../shared/providers/storage/storageHelper';
import { PhoneNumberPipe } from '../shared/pipes/phone-number.pipe';
import { AllowOnlyDirective } from '../shared/directives/allow-only.directive';
import { AppInterceptor } from '../shared/interceptors/app.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfigurationModule } from '../configuration/configuration.module';
import { HttpClientModule } from '@angular/common/http';
import { AttorneyApiModule} from '../webservices/attorney.services';
import {CanActivateRouteGuard} from '../shared/providers/route-guards/can-activate-route-guard.provider';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    HomeComponent,
    PageNotFoundComponent,
    PhoneNumberPipe,
    AllowOnlyDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule, ToastrModule.forRoot(),
    ConfigurationModule,
    HttpClientModule,
    AttorneyApiModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AppInterceptor,
    multi: true
  }, MastersService, StorageHelper, CanActivateRouteGuard],
  exports: [AllowOnlyDirective],
  entryComponents: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
