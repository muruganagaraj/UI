import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ExternalUrl } from './externalurl.configuration';
import { environment } from '../environments/environment';

// To Do : Json reading will be removed once automatic build and deployment enabled
@Injectable()
export class Configuration {
    public ApiServer: string = environment.API_URL;
    public appVersion?: string;
    public uiBaseUrl?: string;
    public externalUrls?: ExternalUrl;
    constructor(private http: HttpClient) {
        this.externalUrls = new ExternalUrl();
        this.getJSON().subscribe((settings: any) => {
            this.ApiServer = settings.apiBaseUrl;
            this.appVersion = settings.appVersion;
            this.uiBaseUrl = settings.uiBaseUrl;
            this.setExternalUrls(settings);
        });
    }

    // tslint:disable-next-line:no-any
    private getJSON(): Observable<any> {
        return this.http.get('./assets/config/app-settings.json');
    }
    // tslint:disable-next-line:no-any
    private setExternalUrls(settings: any): void {
        this.externalUrls.facebook = settings.externalUrls.customerServiceCenter;
    }
}